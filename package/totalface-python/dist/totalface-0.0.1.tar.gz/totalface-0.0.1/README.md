# totalface 😄
* A package that can be tested and evaluated using various models for face detection, landmarks, embedding, attributes, blurring etc.

## owner
* it's me

## example(demo) code
* inference_example.ipynb
