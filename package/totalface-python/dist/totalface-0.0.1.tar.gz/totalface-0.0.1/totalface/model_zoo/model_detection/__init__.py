from .retinaface_torch import RetinaFace
from .retinaface_insightface import RetinaFace
from .dlib_detector import Dlib
from .scrfd import SCRFD_CV
from .blazeface import BlazeFace