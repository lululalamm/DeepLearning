from .load_onnx import Onnx_cv, Onnx_session
from .load_openvino import Openvino,Openvino_multi
from .load_tensorRT import TrtModel
from .load_tensorRT_multiple import load
from .load_torch import TorchModel