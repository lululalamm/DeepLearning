from .load_onnx import Onnx
from .load_openvino import Openvino,Openvino_multi
from .load_tensorRT import TrtModel
from .load_tensorRT_multiple import load