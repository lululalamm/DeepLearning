from .yolov7 import Yolov7
from .yolov5 import Yolov5
from .yolox import YoloX