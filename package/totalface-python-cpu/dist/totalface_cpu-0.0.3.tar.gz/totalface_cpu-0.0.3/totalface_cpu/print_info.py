import os
import numpy as np

def info():
    print("owner: lululalamm(yoonminsun)")
