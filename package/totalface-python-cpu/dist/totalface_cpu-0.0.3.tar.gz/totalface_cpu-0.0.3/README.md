# totalface - cpu version 😄
* A package that can be tested and evaluated using various models for face detection, landmarks, embedding, attributes, blurring etc.
* only use cpu version

## owner
* it's me

## example(demo) code
* inference_example.ipynb
